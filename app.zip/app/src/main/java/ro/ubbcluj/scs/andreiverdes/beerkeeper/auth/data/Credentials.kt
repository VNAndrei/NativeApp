package ro.ubbcluj.scs.andreiverdes.beerkeeper.auth.data

data class Credentials(
    val username: String,
    val password: String
)