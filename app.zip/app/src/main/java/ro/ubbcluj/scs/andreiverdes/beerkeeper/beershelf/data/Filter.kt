package ro.ubbcluj.scs.andreiverdes.beerkeeper.beershelf.data

class Filter {
    var ale :Boolean =false
    var lager :Boolean =false
    var hybrid :Boolean =false
}