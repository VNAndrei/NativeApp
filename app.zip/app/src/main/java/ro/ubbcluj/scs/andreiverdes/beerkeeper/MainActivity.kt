package ro.ubbcluj.scs.andreiverdes.beerkeeper

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import ro.ubbcluj.scs.andreiverdes.beerkeeper.infrastructure.PreferenceManager

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        PreferenceManager.initPreferences(this.getPreferences(Context.MODE_PRIVATE))
    }
}

